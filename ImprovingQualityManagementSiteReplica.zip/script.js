// Global Variables
let currentSection = 'dashboard';
let plans = [
    {
        id: 1,
        name: 'Plano de Melhoria Contínua Q1',
        sector: 'Qualidade',
        responsible: 'Maria Silva',
        email: 'maria.silva@empresa.com',
        createdAt: '2025-01-15',
        status: 'pendente',
        progress: 25,
        priority: 'alta',
        description: 'Implementação de melhorias nos processos de qualidade'
    },
    {
        id: 2,
        name: 'Otimização de Processos',
        sector: 'Produção',
        responsible: 'Carlos Oliveira',
        email: 'carlos.oliveira@empresa.com',
        createdAt: '2025-01-20',
        status: 'em-andamento',
        progress: 60,
        priority: 'media',
        description: 'Otimização dos processos produtivos para redução de custos'
    },
    {
        id: 3,
        name: 'Treinamento de Equipe',
        sector: 'RH',
        responsible: 'Ana Santos',
        email: 'ana.santos@empresa.com',
        createdAt: '2025-01-10',
        status: 'concluido',
        progress: 100,
        priority: 'baixa',
        description: 'Programa de treinamento para novos colaboradores'
    }
];

// DOM Elements
const sections = document.querySelectorAll('.section');
const navLinks = document.querySelectorAll('.nav-link');
const plansTableBody = document.getElementById('plansTableBody');
const searchInput = document.getElementById('searchInput');
const planForm = document.getElementById('planForm');

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    animateCounters();
    initializeCharts();
    renderPlansTable();
});

// Initialize Application
function initializeApp() {
    showSection('dashboard');
    updateStats();
    
    // Set current date in form
    const today = new Date().toISOString().split('T')[0];
    const planDateInput = document.getElementById('planDate');
    if (planDateInput) {
        planDateInput.value = today;
    }
}

// Setup Event Listeners
function setupEventListeners() {
    // Navigation
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetSection = link.getAttribute('href').substring(1);
            showSection(targetSection);
            updateActiveNavLink(link);
        });
    });

    // Search functionality
    if (searchInput) {
        searchInput.addEventListener('input', debounce(filterPlans, 300));
    }

    // Form submission
    if (planForm) {
        planForm.addEventListener('submit', handlePlanSubmission);
    }

    // Filter selects
    const filterSelects = document.querySelectorAll('.filter-select');
    filterSelects.forEach(select => {
        select.addEventListener('change', filterPlans);
    });

    // Chart controls
    const chartBtns = document.querySelectorAll('.chart-btn');
    chartBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            chartBtns.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            updateChart(e.target.textContent);
        });
    });
}

// Navigation Functions
function showSection(sectionId) {
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        targetSection.classList.add('fade-in-up');
        currentSection = sectionId;
    }
}

function updateActiveNavLink(activeLink) {
    navLinks.forEach(link => {
        link.classList.remove('active');
    });
    activeLink.classList.add('active');
}

// Counter Animation
function animateCounters() {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-count'));
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const timer = setInterval(() => {
            current += step;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            counter.textContent = Math.floor(current);
        }, 16);
    });
}

// Charts Initialization
function initializeCharts() {
    initializeProgressChart();
    initializeStatusChart();
}

function initializeProgressChart() {
    const ctx = document.getElementById('progressChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
            datasets: [{
                label: 'Planos Criados',
                data: [12, 19, 8, 15, 22, 18],
                borderColor: '#4F46E5',
                backgroundColor: 'rgba(79, 70, 229, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'Planos Concluídos',
                data: [8, 12, 6, 10, 16, 14],
                borderColor: '#10B981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

function initializeStatusChart() {
    const ctx = document.getElementById('statusChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pendente', 'Em Andamento', 'Concluído'],
            datasets: [{
                data: [8, 5, 7],
                backgroundColor: [
                    '#F59E0B',
                    '#3B82F6',
                    '#10B981'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Plans Management
function renderPlansTable() {
    if (!plansTableBody) return;

    plansTableBody.innerHTML = '';
    
    plans.forEach(plan => {
        const row = createPlanRow(plan);
        plansTableBody.appendChild(row);
    });
}

function createPlanRow(plan) {
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>
            <div style="font-weight: 600; color: var(--gray-800);">${plan.name}</div>
            <div style="font-size: 0.875rem; color: var(--gray-500);">${plan.description}</div>
        </td>
        <td>${plan.sector}</td>
        <td>
            <div>${plan.responsible}</div>
            <div style="font-size: 0.875rem; color: var(--gray-500);">${plan.email}</div>
        </td>
        <td>${formatDate(plan.createdAt)}</td>
        <td>
            <span class="status-badge ${plan.status}">${getStatusText(plan.status)}</span>
        </td>
        <td>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${plan.progress}%"></div>
            </div>
            <div style="font-size: 0.875rem; color: var(--gray-500); margin-top: 4px;">${plan.progress}%</div>
        </td>
        <td>
            <div style="display: flex; gap: 8px;">
                <button class="btn btn-sm btn-icon btn-outline" onclick="editPlan(${plan.id})" title="Editar">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-icon btn-outline" onclick="viewPlan(${plan.id})" title="Visualizar">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-icon btn-outline" onclick="deletePlan(${plan.id})" title="Excluir" style="color: var(--error-color); border-color: var(--error-color);">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </td>
    `;
    return row;
}

function filterPlans() {
    const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
    const statusFilter = document.querySelector('.filter-select:nth-child(1)').value;
    const sectorFilter = document.querySelector('.filter-select:nth-child(2)').value;
    
    const filteredPlans = plans.filter(plan => {
        const matchesSearch = plan.name.toLowerCase().includes(searchTerm) ||
                            plan.responsible.toLowerCase().includes(searchTerm) ||
                            plan.sector.toLowerCase().includes(searchTerm);
        
        const matchesStatus = !statusFilter || plan.status === statusFilter;
        const matchesSector = !sectorFilter || plan.sector.toLowerCase() === sectorFilter;
        
        return matchesSearch && matchesStatus && matchesSector;
    });
    
    renderFilteredPlans(filteredPlans);
}

function renderFilteredPlans(filteredPlans) {
    if (!plansTableBody) return;

    plansTableBody.innerHTML = '';
    
    if (filteredPlans.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="7" style="text-align: center; padding: 2rem; color: var(--gray-500);">
                <i class="fas fa-search" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                Nenhum plano encontrado
            </td>
        `;
        plansTableBody.appendChild(row);
        return;
    }
    
    filteredPlans.forEach(plan => {
        const row = createPlanRow(plan);
        plansTableBody.appendChild(row);
    });
}

// Plan Actions
function editPlan(planId) {
    const plan = plans.find(p => p.id === planId);
    if (plan) {
        populateForm(plan);
        openModal('planModal');
    }
}

function viewPlan(planId) {
    const plan = plans.find(p => p.id === planId);
    if (plan) {
        showToast(`Visualizando plano: ${plan.name}`, 'info');
    }
}

function deletePlan(planId) {
    if (confirm('Tem certeza que deseja excluir este plano?')) {
        plans = plans.filter(p => p.id !== planId);
        renderPlansTable();
        updateStats();
        showToast('Plano excluído com sucesso!', 'success');
    }
}

// Form Handling
function handlePlanSubmission(e) {
    e.preventDefault();
    
    showLoading();
    
    setTimeout(() => {
        const formData = new FormData(planForm);
        const newPlan = {
            id: Date.now(),
            name: formData.get('planName'),
            sector: formData.get('planSector'),
            responsible: formData.get('planResponsible'),
            email: formData.get('planEmail'),
            createdAt: formData.get('planDate'),
            status: 'pendente',
            progress: 0,
            priority: formData.get('planPriority'),
            description: formData.get('planDescription') || 'Sem descrição'
        };
        
        plans.push(newPlan);
        renderPlansTable();
        updateStats();
        closeModal('planModal');
        planForm.reset();
        hideLoading();
        showToast('Plano criado com sucesso!', 'success');
    }, 1000);
}

function populateForm(plan) {
    document.getElementById('planName').value = plan.name;
    document.getElementById('planSector').value = plan.sector.toLowerCase();
    document.getElementById('planResponsible').value = plan.responsible;
    document.getElementById('planEmail').value = plan.email;
    document.getElementById('planDate').value = plan.createdAt;
    document.getElementById('planPriority').value = plan.priority;
    document.getElementById('planDescription').value = plan.description;
}

// Modal Functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
        
        // Reset form if it's the plan modal
        if (modalId === 'planModal' && planForm) {
            planForm.reset();
        }
    }
}

// Close modal when clicking outside
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        closeModal(e.target.id);
    }
});

// Loading Functions
function showLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.add('active');
    }
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.remove('active');
    }
}

// Toast Notifications
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <div style="display: flex; align-items: center; gap: 12px;">
            <i class="fas fa-${getToastIcon(type)}"></i>
            <span>${message}</span>
        </div>
    `;

    container.appendChild(toast);

    // Auto remove after 5 seconds
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s ease-out reverse';
        setTimeout(() => {
            if (container.contains(toast)) {
                container.removeChild(toast);
            }
        }, 300);
    }, 5000);
}

function getToastIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Utility Functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

function getStatusText(status) {
    const statusMap = {
        'pendente': 'Pendente',
        'em-andamento': 'Em Andamento',
        'concluido': 'Concluído'
    };
    return statusMap[status] || status;
}

function updateStats() {
    const totalPlans = plans.length;
    const pendingPlans = plans.filter(p => p.status === 'pendente').length;
    const completedPlans = plans.filter(p => p.status === 'concluido').length;
    const inProgressPlans = plans.filter(p => p.status === 'em-andamento').length;

    // Update counter data attributes
    const counters = document.querySelectorAll('.stat-number');
    if (counters[0]) counters[0].setAttribute('data-count', totalPlans);
    if (counters[1]) counters[1].setAttribute('data-count', pendingPlans);
    if (counters[2]) counters[2].setAttribute('data-count', completedPlans);
    if (counters[3]) counters[3].setAttribute('data-count', '24'); // Static collaborators count
}

function updateChart(period) {
    // This would update the chart based on the selected period
    console.log(`Updating chart for period: ${period}`);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + N for new plan
    if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
        e.preventDefault();
        openModal('planModal');
    }
    
    // Escape to close modals
    if (e.key === 'Escape') {
        const activeModal = document.querySelector('.modal.active');
        if (activeModal) {
            closeModal(activeModal.id);
        }
    }
});

// Auto-save form data to localStorage
function autoSaveForm() {
    if (!planForm) return;
    
    const formData = new FormData(planForm);
    const data = {};
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    localStorage.setItem('planFormData', JSON.stringify(data));
}

function restoreFormData() {
    const savedData = localStorage.getItem('planFormData');
    if (savedData && planForm) {
        const data = JSON.parse(savedData);
        Object.keys(data).forEach(key => {
            const input = planForm.querySelector(`[name="${key}"]`);
            if (input) {
                input.value = data[key];
            }
        });
    }
}

// Initialize form auto-save
if (planForm) {
    const inputs = planForm.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('input', debounce(autoSaveForm, 500));
    });
    
    // Restore data on page load
    restoreFormData();
    
    // Clear saved data on successful submission
    planForm.addEventListener('submit', () => {
        localStorage.removeItem('planFormData');
    });
}

// Performance monitoring
function measurePerformance() {
    if ('performance' in window) {
        window.addEventListener('load', () => {
            const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
            console.log(`Page load time: ${loadTime}ms`);
        });
    }
}

measurePerformance();

// Service Worker registration for offline support
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

