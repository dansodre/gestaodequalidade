from flask import Blueprint, request, jsonify
from supabase_client import supabase_client
from email_service import email_service
from auth import require_auth, require_admin
from datetime import datetime
import uuid

plans_bp = Blueprint('plans', __name__)

@plans_bp.route('/api/plans', methods=['GET'])
@require_auth
def get_plans():
    """Obter todos os planos de ação"""
    try:
        # Parâmetros de filtro
        status = request.args.get('status')
        sector = request.args.get('sector')
        search = request.args.get('search')
        
        # Construir query
        query = supabase_client.table('plans_with_actions').select('*')
        
        if status:
            query = query.eq('status', status)
        if sector:
            query = query.ilike('sector', f'%{sector}%')
        if search:
            query = query.or_(f'name.ilike.%{search}%,responsible_elaboration.ilike.%{search}%,sector.ilike.%{search}%')
        
        # Ordenar por data de criação (mais recentes primeiro)
        query = query.order('created_at', desc=True)
        
        response = query.execute()
        
        return jsonify({
            'plans': response.data,
            'total': len(response.data)
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/plans/<plan_id>', methods=['GET'])
@require_auth
def get_plan(plan_id):
    """Obter um plano específico com suas ações"""
    try:
        # Buscar plano
        plan_response = supabase_client.table('plans').select('*').eq('id', plan_id).execute()
        
        if not plan_response.data:
            return jsonify({'error': 'Plano não encontrado'}), 404
        
        plan = plan_response.data[0]
        
        # Buscar ações do plano
        actions_response = supabase_client.table('actions').select('*').eq('plan_id', plan_id).order('created_at').execute()
        
        plan['actions'] = actions_response.data
        
        return jsonify({'plan': plan}), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/plans', methods=['POST'])
@require_auth
def create_plan():
    """Criar novo plano de ação"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = ['name', 'sector', 'responsible_elaboration', 'email_responsible_elaboration']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo obrigatório: {field}'}), 400
        
        # Dados do plano
        plan_data = {
            'name': data['name'],
            'sector': data['sector'],
            'responsible_elaboration': data['responsible_elaboration'],
            'email_responsible_elaboration': data['email_responsible_elaboration'],
            'description': data.get('description', ''),
            'created_by': request.current_user.id,
            'status': 'pending'
        }
        
        # Criar plano
        plan_response = supabase_client.table('plans').insert(plan_data).execute()
        
        if not plan_response.data:
            return jsonify({'error': 'Erro ao criar plano'}), 500
        
        created_plan = plan_response.data[0]
        plan_id = created_plan['id']
        
        # Criar ações se fornecidas
        actions_data = data.get('actions', [])
        created_actions = []
        
        for action in actions_data:
            if not action.get('title') or not action.get('responsible') or not action.get('email_responsible') or not action.get('due_date'):
                continue
            
            action_data = {
                'plan_id': plan_id,
                'title': action['title'],
                'description': action.get('description', ''),
                'responsible': action['responsible'],
                'email_responsible': action['email_responsible'],
                'collaborators': action.get('collaborators', []),
                'due_date': action['due_date'],
                'priority': action.get('priority', 'medium'),
                'status': 'pending'
            }
            
            action_response = supabase_client.table('actions').insert(action_data).execute()
            if action_response.data:
                created_actions.append(action_response.data[0])
        
        # Enviar notificações por e-mail
        try:
            email_service.send_plan_creation_notification(plan_data, actions_data)
        except Exception as e:
            print(f"Erro ao enviar notificação por e-mail: {str(e)}")
        
        # Retornar plano criado com ações
        created_plan['actions'] = created_actions
        
        return jsonify({
            'message': 'Plano criado com sucesso',
            'plan': created_plan
        }), 201
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/plans/<plan_id>', methods=['PUT'])
@require_auth
def update_plan(plan_id):
    """Atualizar plano de ação"""
    try:
        data = request.get_json()
        
        # Verificar se o plano existe
        plan_response = supabase_client.table('plans').select('*').eq('id', plan_id).execute()
        
        if not plan_response.data:
            return jsonify({'error': 'Plano não encontrado'}), 404
        
        plan = plan_response.data[0]
        
        # Verificar permissões (criador ou admin)
        user_data = supabase_client.table('users').select('role').eq('email', request.current_user.email).execute()
        is_admin = user_data.data and user_data.data[0]['role'] == 'admin'
        is_creator = plan['created_by'] == request.current_user.id
        
        if not (is_admin or is_creator):
            return jsonify({'error': 'Sem permissão para editar este plano'}), 403
        
        # Atualizar dados do plano
        update_data = {}
        updatable_fields = ['name', 'sector', 'responsible_elaboration', 'email_responsible_elaboration', 'description', 'status']
        
        for field in updatable_fields:
            if field in data:
                update_data[field] = data[field]
        
        if update_data:
            update_response = supabase_client.table('plans').update(update_data).eq('id', plan_id).execute()
            
            if not update_response.data:
                return jsonify({'error': 'Erro ao atualizar plano'}), 500
        
        return jsonify({'message': 'Plano atualizado com sucesso'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/plans/<plan_id>', methods=['DELETE'])
@require_auth
def delete_plan(plan_id):
    """Excluir plano de ação"""
    try:
        # Verificar se o plano existe
        plan_response = supabase_client.table('plans').select('*').eq('id', plan_id).execute()
        
        if not plan_response.data:
            return jsonify({'error': 'Plano não encontrado'}), 404
        
        plan = plan_response.data[0]
        
        # Verificar permissões (criador ou admin)
        user_data = supabase_client.table('users').select('role').eq('email', request.current_user.email).execute()
        is_admin = user_data.data and user_data.data[0]['role'] == 'admin'
        is_creator = plan['created_by'] == request.current_user.id
        
        if not (is_admin or is_creator):
            return jsonify({'error': 'Sem permissão para excluir este plano'}), 403
        
        # Excluir plano (as ações serão excluídas automaticamente devido ao CASCADE)
        delete_response = supabase_client.table('plans').delete().eq('id', plan_id).execute()
        
        return jsonify({'message': 'Plano excluído com sucesso'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/plans/<plan_id>/actions', methods=['GET'])
@require_auth
def get_plan_actions(plan_id):
    """Obter ações de um plano específico"""
    try:
        # Verificar se o plano existe
        plan_response = supabase_client.table('plans').select('id').eq('id', plan_id).execute()
        
        if not plan_response.data:
            return jsonify({'error': 'Plano não encontrado'}), 404
        
        # Buscar ações
        actions_response = supabase_client.table('actions').select('*').eq('plan_id', plan_id).order('created_at').execute()
        
        return jsonify({
            'actions': actions_response.data,
            'total': len(actions_response.data)
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/plans/<plan_id>/actions', methods=['POST'])
@require_auth
def create_action(plan_id):
    """Criar nova ação para um plano"""
    try:
        data = request.get_json()
        
        # Verificar se o plano existe
        plan_response = supabase_client.table('plans').select('*').eq('id', plan_id).execute()
        
        if not plan_response.data:
            return jsonify({'error': 'Plano não encontrado'}), 404
        
        plan = plan_response.data[0]
        
        # Validar dados obrigatórios
        required_fields = ['title', 'responsible', 'email_responsible', 'due_date']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo obrigatório: {field}'}), 400
        
        # Dados da ação
        action_data = {
            'plan_id': plan_id,
            'title': data['title'],
            'description': data.get('description', ''),
            'responsible': data['responsible'],
            'email_responsible': data['email_responsible'],
            'collaborators': data.get('collaborators', []),
            'due_date': data['due_date'],
            'priority': data.get('priority', 'medium'),
            'status': 'pending'
        }
        
        # Criar ação
        action_response = supabase_client.table('actions').insert(action_data).execute()
        
        if not action_response.data:
            return jsonify({'error': 'Erro ao criar ação'}), 500
        
        created_action = action_response.data[0]
        
        # Enviar notificação por e-mail
        try:
            email_service.send_action_assignment_notification(action_data, plan)
        except Exception as e:
            print(f"Erro ao enviar notificação por e-mail: {str(e)}")
        
        return jsonify({
            'message': 'Ação criada com sucesso',
            'action': created_action
        }), 201
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/actions/<action_id>', methods=['PUT'])
@require_auth
def update_action(action_id):
    """Atualizar ação"""
    try:
        data = request.get_json()
        
        # Verificar se a ação existe
        action_response = supabase_client.table('actions').select('*').eq('id', action_id).execute()
        
        if not action_response.data:
            return jsonify({'error': 'Ação não encontrada'}), 404
        
        # Atualizar dados da ação
        update_data = {}
        updatable_fields = ['title', 'description', 'responsible', 'email_responsible', 'collaborators', 'due_date', 'priority', 'status']
        
        for field in updatable_fields:
            if field in data:
                update_data[field] = data[field]
        
        if update_data:
            update_response = supabase_client.table('actions').update(update_data).eq('id', action_id).execute()
            
            if not update_response.data:
                return jsonify({'error': 'Erro ao atualizar ação'}), 500
        
        return jsonify({'message': 'Ação atualizada com sucesso'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/actions/<action_id>', methods=['DELETE'])
@require_auth
def delete_action(action_id):
    """Excluir ação"""
    try:
        # Verificar se a ação existe
        action_response = supabase_client.table('actions').select('*').eq('id', action_id).execute()
        
        if not action_response.data:
            return jsonify({'error': 'Ação não encontrada'}), 404
        
        # Excluir ação
        delete_response = supabase_client.table('actions').delete().eq('id', action_id).execute()
        
        return jsonify({'message': 'Ação excluída com sucesso'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

@plans_bp.route('/api/dashboard/stats', methods=['GET'])
@require_auth
def get_dashboard_stats():
    """Obter estatísticas para o dashboard"""
    try:
        # Buscar estatísticas usando a view
        stats_response = supabase_client.table('dashboard_stats').select('*').execute()
        
        if stats_response.data:
            stats = stats_response.data[0]
        else:
            # Fallback se a view não estiver disponível
            stats = {
                'total_plans': 0,
                'pending_plans': 0,
                'in_progress_plans': 0,
                'completed_plans': 0,
                'total_actions': 0,
                'pending_actions': 0,
                'completed_actions': 0,
                'total_users': 0,
                'active_users': 0
            }
        
        return jsonify({'stats': stats}), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor', 'details': str(e)}), 500

