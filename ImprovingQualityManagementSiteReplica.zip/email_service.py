import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
import os

class EmailService:
    def __init__(self):
        # Configurações de e-mail (podem ser movidas para variáveis de ambiente)
        self.smtp_server = "smtp.gmail.com"
        self.port = 587
        self.sender_email = os.getenv("EMAIL_USER", "sistema@gestaodequalidade.com")
        self.password = os.getenv("EMAIL_PASSWORD", "senha_do_email")
        
    def send_email(self, to_emails, subject, body, is_html=True):
        """
        Envia e-mail para uma lista de destinatários
        """
        try:
            # Criar mensagem
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = self.sender_email
            message["To"] = ", ".join(to_emails) if isinstance(to_emails, list) else to_emails
            
            # Adicionar corpo do e-mail
            if is_html:
                part = MIMEText(body, "html")
            else:
                part = MIMEText(body, "plain")
            
            message.attach(part)
            
            # Criar conexão segura e enviar e-mail
            context = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_server, self.port) as server:
                server.starttls(context=context)
                server.login(self.sender_email, self.password)
                text = message.as_string()
                server.sendmail(self.sender_email, to_emails, text)
            
            return True, "E-mail enviado com sucesso"
            
        except Exception as e:
            return False, f"Erro ao enviar e-mail: {str(e)}"

    def send_plan_creation_notification(self, plan, actions):
        """
        Envia notificação de criação de plano de ação
        """
        # Coletar todos os e-mails envolvidos
        emails = [plan["email_responsible_elaboration"]]
        for action_item in actions:
            if action_item["email_responsible"] not in emails:
                emails.append(action_item["email_responsible"])
        
        # Criar conteúdo do e-mail
        subject = f"Novo Plano de Ação Criado: {plan['name']}"
        
        body = self._create_plan_email_body(plan, actions, "criado")
        
        return self.send_email(emails, subject, body)
    
    def send_plan_update_notification(self, plan, actions):
        """
        Envia notificação de atualização de plano de ação
        """
        # Coletar todos os e-mails envolvidos
        emails = [plan["email_responsible_elaboration"]]
        for action_item in actions:
            if action_item["email_responsible"] not in emails:
                emails.append(action_item["email_responsible"])
        
        # Criar conteúdo do e-mail
        subject = f"Plano de Ação Atualizado: {plan['name']}"
        
        body = self._create_plan_email_body(plan, actions, "atualizado")
        
        return self.send_email(emails, subject, body)
    
    def send_action_assignment_notification(self, action, plan):
        """
        Envia notificação específica para responsável por uma ação
        """
        subject = f"Nova Ação Atribuída: {action['title']}"
        
        body = self._create_action_email_body(action, plan)
        
        return self.send_email([action["email_responsible"]], subject, body)
    
    def _create_plan_email_body(self, plan, actions, action_type):
        """
        Cria o corpo do e-mail para notificações de plano
        """
        actions_html = ""
        for i, action_item in enumerate(actions, 1):
            actions_html += f"""
            <tr style="border-bottom: 1px solid #e1e5e9;">
                <td style="padding: 12px; border: 1px solid #e1e5e9;">{i}</td>
                <td style="padding: 12px; border: 1px solid #e1e5e9;">{action_item['title']}</td>
                <td style="padding: 12px; border: 1px solid #e1e5e9;">{action_item['responsible']}</td>
                <td style="padding: 12px; border: 1px solid #e1e5e9;">{action_item['email_responsible']}</td>
                <td style="padding: 12px; border: 1px solid #e1e5e9;">{action_item['due_date']}</td>
                <td style="padding: 12px; border: 1px solid #e1e5e9;">{action_item['status']}</td>
            </tr>
            """
        
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 800px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #4A90E2, #357ABD); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                .plan-info {{ background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                .actions-table {{ width: 100%; border-collapse: collapse; margin-top: 20px; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                .actions-table th {{ background: #4A90E2; color: white; padding: 15px; text-align: left; }}
                .actions-table td {{ padding: 12px; border: 1px solid #e1e5e9; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 14px; }}
                .status-badge {{ padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }}
                .status-pending {{ background: #FFE5E5; color: #D0021B; }}
                .status-in-progress {{ background: #FFF3CD; color: #856404; }}
                .status-completed {{ background: #D4EDDA; color: #155724; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>📋 Sistema de Gestão de Qualidade</h1>
                    <h2>Plano de Ação {action_type.title()}</h2>
                </div>
                
                <div class="content">
                    <div class="plan-info">
                        <h3>📊 Informações do Plano</h3>
                        <p><strong>Nome do Plano:</strong> {plan['name']}</p>
                        <p><strong>Setor Responsável:</strong> {plan['sector']}</p>
                        <p><strong>Responsável pela Elaboração:</strong> {plan['responsible_elaboration']}</p>
                        <p><strong>E-mail do Responsável:</strong> {plan['email_responsible_elaboration']}</p>
                        <p><strong>Data de Criação:</strong> {plan['created_at']}</p>
                        <p><strong>Status:</strong> <span class="status-badge status-{plan['status']}">{plan['status']}</span></p>
                    </div>
                    
                    <h3>📝 Ações do Plano ({len(actions)} ações)</h3>
                    <table class="actions-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Título da Ação</th>
                                <th>Responsável</th>
                                <th>E-mail</th>
                                <th>Data de Execução</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {actions_html}
                        </tbody>
                    </table>
                    
                    <div style="margin-top: 30px; padding: 20px; background: #e3f2fd; border-radius: 8px; border-left: 4px solid #4A90E2;">
                        <h4>📌 Próximos Passos</h4>
                        <p>• Revise as ações atribuídas a você</p>
                        <p>• Confirme as datas de execução</p>
                        <p>• Entre em contato com os demais responsáveis se necessário</p>
                        <p>• Acesse o sistema para acompanhar o progresso</p>
                    </div>
                </div>
                
                <div class="footer">
                    <p>Este e-mail foi enviado automaticamente pelo Sistema de Gestão de Qualidade.</p>
                    <p>Data de envio: {datetime.now().strftime("%d/%m/%Y às %H:%M")}</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html_body
    
    def _create_action_email_body(self, action, plan):
        """
        Cria o corpo do e-mail para notificações específicas de ação
        """
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #50E3C2, #2ECC71); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                .action-info {{ background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                .plan-info {{ background: #e8f5e8; padding: 15px; border-radius: 8px; margin-bottom: 20px; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 14px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🎯 Nova Ação Atribuída</h1>
                    <p>Você foi designado como responsável por uma nova ação</p>
                </div>
                
                <div class="content">
                    <div class="action-info">
                        <h3>📋 Detalhes da Ação</h3>
                        <p><strong>Título:</strong> {action['title']}</p>
                        <p><strong>Responsável:</strong> {action['responsible']}</p>
                        <p><strong>Data de Execução:</strong> {action['due_date']}</p>
                        <p><strong>Status:</strong> {action['status']}</p>
                        {f'<p><strong>Descrição:</strong> {action["description"]}</p>' if action.get("description") else ''}
                        <p><strong>Justificativa:</strong> {action['justification']}</p>
                        {f'<p><strong>Custo Estimado:</strong> R$ {action["cost"]:.2f}</p>' if action.get("cost") else ''}
                        {f'<p><strong>Fonte de Recurso:</strong> {action["resource_source"]}</p>' if action.get("resource_source") else ''}
                    </div>
                    
                    <div class="plan-info">
                        <h4>📊 Plano de Ação Relacionado</h4>
                        <p><strong>Nome:</strong> {plan['name']}</p>
                        <p><strong>Setor:</strong> {plan['sector']}</p>
                        <p><strong>Responsável pelo Plano:</strong> {plan['responsible_elaboration']}</p>
                    </div>
                    
                    <div style="margin-top: 30px; padding: 20px; background: #fff3cd; border-radius: 8px; border-left: 4px solid #ffc107;">
                        <h4>⚠️ Importante</h4>
                        <p>• Confirme o recebimento desta ação</p>
                        <p>• Verifique a data de execução</p>
                        <p>• Entre em contato com o responsável pelo plano se tiver dúvidas</p>
                        <p>• Acesse o sistema para atualizar o status da ação</p>
                    </div>
                </div>
                
                <div class="footer">
                    <p>Este e-mail foi enviado automaticamente pelo Sistema de Gestão de Qualidade.</p>
                    <p>Data de envio: {datetime.now().strftime("%d/%m/%Y às %H:%M")}</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html_body

# Instância global do serviço de e-mail
email_service = EmailService()

