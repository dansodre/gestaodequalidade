from supabase import create_client, Client
from config import Config

class SupabaseClient:
    _instance = None
    _client = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SupabaseClient, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._client is None:
            Config.validate_config()
            self._client = create_client(
                Config.SUPABASE_URL,
                Config.SUPABASE_SERVICE_KEY  # Corrigido
            )
    
    @property
    def client(self) -> Client:
        return self._client
    
    def get_anon_client(self) -> Client:
        """Retorna um cliente com chave anônima para operações do frontend"""
        return create_client(
            Config.SUPABASE_URL,
            Config.SUPABASE_KEY  # Corrigido
        )

# Instância global do cliente Supabase
supabase_client = SupabaseClient().client

