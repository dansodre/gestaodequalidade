from flask import Blueprint, request, jsonify, session
from supabase_client import supabase_client
from datetime import datetime
import hashlib

users_bp = Blueprint('users', __name__)

def hash_password(password):
    """Hash da senha usando SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def require_admin():
    """Decorator para verificar se o usuário é admin"""
    if session.get('user_role') != 'admin':
        return jsonify({'error': 'Acesso negado'}), 403
    return None

@users_bp.route('/api/users', methods=['GET'])
def get_users():
    admin_check = require_admin()
    if admin_check:
        return admin_check
    
    try:
        response = supabase_client.table('users').select('id, email, full_name, role, status, created_at, last_login').execute()
        
        return jsonify({
            'success': True,
            'users': response.data
        })
        
    except Exception as e:
        print(f"Erro ao buscar usuários: {str(e)}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@users_bp.route('/api/users', methods=['POST'])
def create_user():
    admin_check = require_admin()
    if admin_check:
        return admin_check
    
    try:
        data = request.get_json()
        
        # Verificar se e-mail já existe
        existing_user = supabase_client.table('users').select('id').eq('email', data['email']).execute()
        
        if existing_user.data:
            return jsonify({'error': 'E-mail já cadastrado'}), 400
        
        # Hash da senha
        password_hash = hash_password(data['password'])
        
        new_user = {
            'email': data['email'],
            'password': password_hash,
            'full_name': data['full_name'],
            'role': data.get('role', 'user'),
            'status': data.get('status', 'active'),
            'created_at': datetime.now().isoformat()
        }
        
        response = supabase_client.table('users').insert(new_user).execute()
        
        if response.data:
            user = response.data[0]
            # Remover senha do retorno
            user.pop('password', None)
            return jsonify({
                'success': True,
                'user': user
            })
        else:
            return jsonify({'error': 'Erro ao criar usuário'}), 500
            
    except Exception as e:
        print(f"Erro ao criar usuário: {str(e)}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@users_bp.route('/api/users/<user_id>', methods=['PUT'])
def update_user(user_id):
    admin_check = require_admin()
    if admin_check:
        return admin_check
    
    try:
        data = request.get_json()
        
        update_data = {}
        
        # Campos que podem ser atualizados
        if 'full_name' in data:
            update_data['full_name'] = data['full_name']
        if 'role' in data:
            update_data['role'] = data['role']
        if 'status' in data:
            update_data['status'] = data['status']
        if 'password' in data and data['password']:
            update_data['password'] = hash_password(data['password'])
        
        if not update_data:
            return jsonify({'error': 'Nenhum campo para atualizar'}), 400
        
        response = supabase_client.table('users').update(update_data).eq('id', user_id).execute()
        
        if response.data:
            user = response.data[0]
            # Remover senha do retorno
            user.pop('password', None)
            return jsonify({
                'success': True,
                'user': user
            })
        else:
            return jsonify({'error': 'Usuário não encontrado'}), 404
            
    except Exception as e:
        print(f"Erro ao atualizar usuário: {str(e)}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@users_bp.route('/api/users/<user_id>', methods=['DELETE'])
def delete_user(user_id):
    admin_check = require_admin()
    if admin_check:
        return admin_check
    
    try:
        # Não permitir que o admin delete a si mesmo
        if user_id == session.get('user_id'):
            return jsonify({'error': 'Não é possível deletar seu próprio usuário'}), 400
        
        response = supabase_client.table('users').delete().eq('id', user_id).execute()
        
        if response.data:
            return jsonify({'success': True})
        else:
            return jsonify({'error': 'Usuário não encontrado'}), 404
            
    except Exception as e:
        print(f"Erro ao deletar usuário: {str(e)}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@users_bp.route('/api/dashboard/stats', methods=['GET'])
def get_dashboard_stats():
    try:
        # Estatísticas de usuários
        users_response = supabase_client.table('users').select('role, status').execute()
        users_data = users_response.data
        
        total_users = len(users_data)
        admin_users = len([u for u in users_data if u['role'] == 'admin'])
        active_users = len([u for u in users_data if u['status'] == 'active'])
        
        # Estatísticas de planos (usando dados em memória por enquanto)
        plans_response = supabase_client.table('plans').select('status').execute()
        plans_data = plans_response.data if plans_response.data else []
        
        total_plans = len(plans_data)
        pending_plans = len([p for p in plans_data if p['status'] == 'pending'])
        in_progress_plans = len([p for p in plans_data if p['status'] == 'in_progress'])
        completed_plans = len([p for p in plans_data if p['status'] == 'completed'])
        
        # Estatísticas de ações
        actions_response = supabase_client.table('actions').select('status').execute()
        actions_data = actions_response.data if actions_response.data else []
        
        total_actions = len(actions_data)
        pending_actions = len([a for a in actions_data if a['status'] == 'pending'])
        in_progress_actions = len([a for a in actions_data if a['status'] == 'in_progress'])
        completed_actions = len([a for a in actions_data if a['status'] == 'completed'])
        
        return jsonify({
            'users': {
                'total': total_users,
                'admin': admin_users,
                'active': active_users
            },
            'plans': {
                'total': total_plans,
                'pending': pending_plans,
                'in_progress': in_progress_plans,
                'completed': completed_plans
            },
            'actions': {
                'total': total_actions,
                'pending': pending_actions,
                'in_progress': in_progress_actions,
                'completed': completed_actions
            }
        })
        
    except Exception as e:
        print(f"Erro ao buscar estatísticas: {str(e)}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

